module.exports = {
    base_path: "/api"
}