require('dotenv').config()
require('./services').start()